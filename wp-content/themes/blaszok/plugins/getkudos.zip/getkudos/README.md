
== Installation ==

Compile the file 
zip -r getkudos.zip getkudos -x \*.git\* -x \*.DS_Store\* -x README.md
