<?php
require_once dirname( __FILE__ ) . '/Getkudos_LifeCycle.php';
/*
	WIDGET CLASSES
*/

class gkInlineWidget extends WP_Widget {
	function gkInlineWidget() {
		$widget_ops = array('classname' => 'gkInlineWidget',
				'description' => __('GetKudos widget to display your social testimonials'));
		$this->WP_Widget('gkInlineWidget',
			__('GetKudos Inline Widget', 'getkudos-plugin'),
			$widget_ops);
	}

	function widget($args, $instance) {
		$code = get_option('getkudosCode');
		if ($code) {
			echo '<!-- Start of GetKudos Inline Script -->
<div class="getkudos-inline" data-site-name="'.$code.
'" data-layout="inline"></div>

<script>
(function(w,t,gk,d,s,fs){if(w[gk])return;d=w.document;w[gk]=function(){
(w[gk]._=w[gk]._||[]).push(arguments)};s=d.createElement(t);s.async=!0;
s.src="//static.getkudos.me/widget.js";fs=d.getElementsByTagName(t)[0];
fs.parentNode.insertBefore(s,fs)})(window,"script","getkudos");

getkudos("parse");
</script>
<!-- End of GetKudos Inline Script -->"';
		}
	}
}

class gkFloatingWidget extends WP_Widget {
	function gkFloatingWidget() {
		$widget_ops = array('classname' => 'gkFloatingWidget',
				'description' => __('GetKudos widget to display your social testimonials'));
		$this->WP_Widget('gkFloatingWidget',
			__('GetKudos Floating Widget', 'getkudos-plugin'),
			$widget_ops);
	}

	function widget($args, $instance) {
		$code = get_option('getkudosCode');
		if ($code) {
			echo "<!--Start of GetKudos Script-->
	<script>
	(function(w,t,gk,d,s,fs){if(w[gk])return;d=w.document;w[gk]=function(){
	(w[gk]._=w[gk]._||[]).push(arguments)};s=d.createElement(t);s.async=!0;
	s.src='//static.getkudos.me/widget.js';fs=d.getElementsByTagName(t)[0];
	fs.parentNode.insertBefore(s,fs)})(window,'script','getkudos');

	getkudos('create', '".$code."');
	</script>
	<!--End of GetKudos Script-->";
		}
	}
}

/*
	HELPER FUNCTIONS
*/

function getkudos_check_site_name($siteName) {
	$post_url = 'https://www.getkudos.me/'.$siteName.'/post';
	$response = wp_remote_get($post_url);
	if ($response) {
		return true;
	} else {
		return false;
	}
}

/*
	MAIN CLASS
*/

class Getkudos_Plugin extends Getkudos_LifeCycle {

	/**
	 * See: http://plugin.michael-simpson.com/?page_id=31
	 * @return array of option meta data.
	 */
	public function getOptionMetaData() {
		//	http://plugin.michael-simpson.com/?page_id=31
		return array(
			//'_version' => array('Installed Version'), // Leave this one commented-out. Uncomment to test upgrades.
			'ATextInput' => array(__('Enter in some text', 'my-awesome-plugin')),
			'Donated' => array(__('I have donated to this plugin', 'my-awesome-plugin'), 'false', 'true'),
			'CanSeeSubmitData' => array(__('Can See Submission data', 'my-awesome-plugin'),
										'Administrator', 'Editor', 'Author', 'Contributor', 'Subscriber', 'Anyone')
		);
	}

//	protected function getOptionValueI18nString($optionValue) {
//		$i18nValue = parent::getOptionValueI18nString($optionValue);
//		return $i18nValue;
//	}

	protected function initOptions() {
		$options = $this->getOptionMetaData();
		if (!empty($options)) {
			foreach ($options as $key => $arr) {
				if (is_array($arr) && count($arr > 1)) {
					$this->addOption($key, $arr[1]);
				}
			}
		}
	}

	public function getPluginDisplayName() {
		return 'getkudos';
	}

	protected function getMainPluginFileName() {
		return 'getkudos.php';
	}

	/**
	 * See: http://plugin.michael-simpson.com/?page_id=101
	 * Called by install() to create any database tables if needed.
	 * Best Practice:
	 * (1) Prefix all table names with $wpdb->prefix
	 * (2) make table names lower case only
	 * @return void
	 */
	protected function installDatabaseTables() {
		//		global $wpdb;
		//		$tableName = $this->prefixTableName('mytable');
		//		$wpdb->query("CREATE TABLE IF NOT EXISTS `$tableName` (
		//			`id` INTEGER NOT NULL");
	}

	/**
	 * See: http://plugin.michael-simpson.com/?page_id=101
	 * Drop plugin-created tables on uninstall.
	 * @return void
	 */
	protected function unInstallDatabaseTables() {
		//		global $wpdb;
		//		$tableName = $this->prefixTableName('mytable');
		//		$wpdb->query("DROP TABLE IF EXISTS `$tableName`");
	}


	/**
	 * Perform actions when upgrading from version X to version Y
	 * See: http://plugin.michael-simpson.com/?page_id=35
	 * @return void
	 */
	public function upgrade() {
	}

	public function addActionsAndFilters() {
		add_filter('widget_text', 'do_shortcode');
		add_action('admin_menu', array(&$this, 'addSettingsSubMenuPage'));
		add_action( 'admin_init', array(&$this, 'initAdmin'));
		add_shortcode('getkudos_floating', array($this, 'gkShortCodeFloating'));
		add_shortcode('getkudos_inline', array($this, 'gkShortCodeInline')) ;
		add_action('widgets_init', array(&$this, 'initInlineWidget'));
		add_action('widgets_init', array(&$this, 'initFloatingWidget'));
	}

	public function settingsPage() {
		$a = get_option('getkudosCode');
		if ($a == '') {
			$pass = 0;
		} else {
			$pass = 1;
		}
		if (isset($_GET["action"]) && $_GET["action"]=="deactivate") {
			update_option('getkudosCode', "");
			$pass = 0;
		}
		if (isset($_GET["action"]) && $_GET["action"]=="linkUp") {
			if (!getkudos_check_site_name($_GET["siteName"])) {
				$error['login'] = 'The sitename doesn\'t exist';
				$pass = 0;
			} else {
				$pass = 1;
				update_option('getkudosCode', $_GET["siteName"]);
			}
		}

		if ($pass == 1){
			// remove_submenu_page('getkudos_settings', 'getkudos_signup');
			?>
		<div class="wrap">
			<div id="existingform">
				<div class="metabox-holder">
					<div class="postbox">
						<div style="padding:10px;">
			Congratulations on successfully installing the GetKudos WordPress plugin!
			<br />
			<br />
			<a class="button-secondary"
			href="admin.php?page=getkudos_settings&action=deactivate">Deactivate</a>
			<br />
			<br />
			 <a class="button-secondary" href="https://dashboard.getkudos.me">Visit Dashboard</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php

		} else {

	?>

	<div class="wrap">
	<div id="existingform">
		<div class="metabox-holder">
			<div class="postbox">
				<h3 class="hndle"><span>Link up with your GetKudos account</span></h3>
				<div style="padding:10px;">
				<?php if (isset($error) && isset($error["login"])) { echo '<div id="message" class="error">'.$error["login"].'</div>'; } ?>
				<form method="get" action="admin.php">
					<input type="hidden" name="page" value="getkudos_settings">
					<input type="hidden" name="action" value="linkUp">
					<table class="form-table">

							<tr valign="top">
							<th scope="row">Site Name</th>
							<td><input type="text" name="siteName" value="" /></td>
							</tr>
					 </table>
						<br/>
						Find out your site name from <u>https://dashboard.getkudos.me</u>. Your site name is in this format: <u>dashboard.getkudos.me/{your-site-name}</u>. The GetKudos card will appear on your website once your account is linked up.
						<br/>
						<p class="submit">
						<input type="submit" class="button-primary" value="Link Up" />
						Don't have a GetKudos account? <a href="<?php echo GETKUDOS_SIGNUP_URL; ?>" target="_blank" data-popup="true">Sign up now</a>.
						</p>

				</form>

				</div>
			</div>
		</div>
	</div>

	</div>
	<?php
		}
	}

	public function initInlineWidget() {
		register_widget('gkInlineWidget');
	}
	public function initFloatingWidget() {
		register_widget('gkFloatingWidget');
	}

	public function gkShortCodeInline() {
		$code = get_option('getkudosCode');
		if ($code == "" || !getkudos_check_site_name($code)) { return ''; }
		$gk_inline_widget = '<!-- Start of GetKudos Inline Script -->
<div class="getkudos-inline" data-site-name="'.$code.
'" data-layout="inline"></div>

<script>
(function(w,t,gk,d,s,fs){if(w[gk])return;d=w.document;w[gk]=function(){
(w[gk]._=w[gk]._||[]).push(arguments)};s=d.createElement(t);s.async=!0;
s.src="//static.getkudos.me/widget.js";fs=d.getElementsByTagName(t)[0];
fs.parentNode.insertBefore(s,fs)})(window,"script","getkudos");

getkudos("parse");
</script>
<!-- End of GetKudos Inline Script -->"';
		return $gk_inline_widget;
	}

	public function gkShortCodeFloating() {
		$code = get_option('getkudosCode');
		if ($code == "" || !getkudos_check_site_name($code)) { return ''; }
		$gk_floating_widget = "<!--Start of GetKudos Script-->
	<script>
	(function(w,t,gk,d,s,fs){if(w[gk])return;d=w.document;w[gk]=function(){
	(w[gk]._=w[gk]._||[]).push(arguments)};s=d.createElement(t);s.async=!0;
	s.src='//static.getkudos.me/widget.js';fs=d.getElementsByTagName(t)[0];
	fs.parentNode.insertBefore(s,fs)})(window,'script','getkudos');

	getkudos('create', '".$code."');
	</script>
	<!--End of GetKudos Script-->
	";
		return $gk_floating_widget;
	}

	public function gkDashboard() {
		echo "<iframe src=\"https://getkudos.me/login\"".
			" width=\"1000px\" height=\"800\"></iframe>";
		echo "<br /> You can also <a href='https://dashboard.getkudos.me'>";
		echo "access the Dashboard on the separate window</a>.";
	}

/*

All the actions

*/
	public function initAdmin() {
		$role = get_role( 'administrator' );
		$role->add_cap( 'access_getkudos' );
	}

	public function gkGoDashBoard() {
		echo "_parent.location.href = 'https://dashboard.getkudos.me'";
	}

}
