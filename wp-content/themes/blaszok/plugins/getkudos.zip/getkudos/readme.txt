=== getkudos ===
Contributors: Ngoc Tran
Donate link: https://getkudos.me
Tags: Testimonials,Kudos,Social Testimonials,Testimonial Widget,Testimonial,Wp Testimonial,GetKudos,GetKudos,GetKudos,Site Reviews,Reviews,Social Reviews
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 1.0.1

GetKudos Product

== Description ==

GetKudos is a business tool for collecting and displaying customer reviews and testimonials, optimized for authenticity in today's age of social media. We aim for a fuss-free solution without you requiring engineering help.

== Description ==

GetKudos helps Shopify store owners to collect and display positive reviews, or Kudos, from real people. Kudos are displayed on an easily customizable widget on your website. Every single review is linked to the reviewer's social media account, making the review authentic and trustworthy. GetKudos is free, and getting started takes less than 5 minutes.

**How it works:**

* Collect:— Import reviews from your social channels into GetKudos. No reviews? No fear, you can get new reviews with our Collect-Kudos feature.
* Curate:— Curate reviews into Kudos for display on your website. GetKudos intelligently surfaces the best reviews to help save you time.
* Display:— Show off your best reviews by embedding the GetKudos widget in your website. Customize it to suit your store's branding needs.

**Benefits:**

* Authenticity:— The reviews are linked to the reviewer's social media accounts, making reviews for your products authentic, honest, and trustworthy.
* Convenience:— It takes one click to curate reviews for display on your website. GetKudos also intelligently surfaces the best for fast curation.
* More Reviews:— Easily import reviews from your social channels. No reviews? No fear, you can get new reviews easily with the Collect–Kudos features.
* Professional:— Designed to be mobile–friendly with multiple widget sizes to choose from, visitors can view your Kudos any time, any place and from any device. You can brand it with your own colors as well.

**All the features you need, with none of the clutter**

* One click to curate reviews into Kudos for display on your store
* Easily showcase other accolades with the Custom–Reviews feature
* Multiple widget customization options available
* Easily import existing reviews from your Facebook page or Twitter account
* Easy setup and installation
* Beautiful form for customers to leave you Kudos
* Analytics to track your reviews over time

== Installation ==

*Server Requirements:* PHP4 or PHP5.

*Wordpress versions:* Wordpress 2.7 and up.

* Install plugin from WordPress directory and activate it.
* Under GetKudos section, click on Account Setup to link up your GetKudos account.
* Once your account is linked, you can insert the widget to your website in two ways:
*   Widget Tab: Under widget tab, you will find GetKudos Floating Widget and GetKudos Inline Widget plugin. By dragging and dropping the widget to the destination component, you will be able to set up the widget in your wordpress site.
*   Directly insert on the page by inserting the text to the pages:
*       getkudos_floating: Insert floating widget to the page
*       getkudos_inline: Insert inline widget to the page

Visit our blog <a href="https://">post</a>.

== Frequently Asked Questions ==
= How did you come up with the idea for GetKudos?

Actually we faced an interesting problem while developing Zopim. Although we had great feedback, it was difficult to always find the really good comments. We wanted to be able to highlight our favorite testimonials and there just wasn't a good option available in the market. So, we decided to build our own social testimonial tool.

= I signed up with email but did not receive any email yet.

Currently, users who sign up with email only join a waiting list and do not get to use the product immediately. To try GetKudos immediately, try signing up with Facebook or Twitter instead. GetKudos emphasises credible reviews that are verified by social media and hence email addresses do not demonstrate the full value of our product. Thanks for understanding!

= Will you spam my Facebook/ Twitter feed?Absolutely not. 

We dislike Candy Crush as much as you do.

= What information do you get from my Facebook/Twitter account?

From Facebook, we only import comments left by your fans in your "Recent Posts by Others" section. This usually appears in the right column of your page. For Twitter, we import everything under the sun but created a nifty feature called "Suggested Reviews" to make things easy for you.

= I see nothing in my dashboard after connecting my Facebook page.

You might have turned off "Recent Posts by Others" in your FB page. You can turn on quickly if you want to. At the top of your FB page, click on Edit Page>Edit Settings. Select Settings (2nd tab), not Page info. Your 3rd field "Post VIsibility" is likely to be switched off, turn it back on and you will see "Recent Posts by Others" again. Here's a screenshot to help you: http://cl.ly/image/1o1u1z0f0H3x

= Where should I insert the GetKudos embed code?

This depends on whether you are talking about the floating widget or the inline widget. Embed instructions are different for each.

= How does "Suggested Reviews" work?

Put simply, this feature can "read" ALL imported reviews at a million times faster than you and intelligently suggest the ones you should select to show on your widget. Only for English reviews.

Put difficultly, we wrote an algorithm that conducts sentiment analysis for every review/testimonial and assigns a sentiment-score. Only reviews/ testimonials above a minimum sentiment-score are suggested for you. This feature is currently only available to English-language content.

= I am missing some comments from Facebook. Are you doing your job?

All the time, when we are awake. If your Facebook comments are in the "Recommendations" section of Facebook, we cannot help because Facebook has no API for that.

= Why is GetKudos only in English? 

In beta, we break things fast and fear you will translate faster than we build. We will feel less insecure about your translation speed after we leave this beta stage in early 2014.

= Does this mean I cannot use GetKudos for my non-English customers?

We are not that selfish. Only the dashboard is in English but your widget and other webpages that will be seen by your customers are all customizable to any language you want (even Klingon and Na'vi!)

== Screenshots ==

1. Dashboard: Floating widget customization
2. Dashboard: Reviews analytics
3. Website overview
4. Dashboard: Feed panel 
5. Dashboard: Tools for collecting Kudos
6. Setup Instruction: Install GetKudos widget to the page by using Wordpress Shortcode 
5. Setup Instruction: Where to find widget tab in admin panel
5. Setup Instruction: Where to find the GetKudos widget within the widget tab

== Changelog ==

= 1.0.1 =


