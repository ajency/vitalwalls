<?php
/*
/*
Plugin Name: GetKudos Widget
Plugin URI: http://www.getkudos.me/?iref=wp_plugin
	  $error['login'] = 'The sitename doesn\'t exist';
Description: This plugin lets you add a widgetized area right above your website's main content (i.e. floating widget). Your GetKudos widget will show customer reviews or testimonials that are authenticated by social channels such as Facebook or Twitter. To start, click on the "GetKudos" tab on your Wordpress right sidebar (below "Settings").
Author: Zopim
Version: 0.0.1
Author URI: http://www.getkudos.me/?iref=wp_plugin
Copyright:
Adopted after plugin template by Micheal Simpson
http://plugin.michael-simpson.com
*/

// define( 'PLUGIN_DIR', plugin_dir_path( __FILE__ ));

$Getkudos_minimalRequiredPhpVersion = '2.7';

/**
 * Check the PHP version and give a useful error message if the user's version is less than the required version
 * @return boolean true if version check passed. If false, triggers an error which WP will handle, by displaying
 * an error message on the Admin page
 */
function Getkudos_noticePhpVersionWrong() {
	global $Getkudos_minimalRequiredPhpVersion;
	echo '<div class="updated fade">' .
	  __('Error: plugin "getkudos" requires a newer version of PHP to be running.',  'getkudos').
			'<br/>' . __('Minimal version of PHP required: ', 'getkudos') . '<strong>' . $Getkudos_minimalRequiredPhpVersion . '</strong>' .
			'<br/>' . __('Your server\'s PHP version: ', 'getkudos') . '<strong>' . phpversion() . '</strong>' .
		 '</div>';
}


function Getkudos_PhpVersionCheck() {
	global $Getkudos_minimalRequiredPhpVersion;
	if (version_compare(phpversion(), $Getkudos_minimalRequiredPhpVersion) < 0) {
		add_action('admin_notices', 'Getkudos_noticePhpVersionWrong');
		return false;
	}
	return true;
}


/**
 * Initialize internationalization (i18n) for this plugin.
 * References:
 *	  http://codex.wordpress.org/I18n_for_WordPress_Developers
 *	  http://www.wdmac.com/how-to-create-a-po-language-translation#more-631
 * @return void
 */
function Getkudos_i18n_init() {
	$pluginDir = dirname(plugin_basename(__FILE__));
	load_plugin_textdomain('getkudos', false, $pluginDir . '/languages/');
}


//////////////////////////////////
// Run initialization
/////////////////////////////////

// First initialize i18n
Getkudos_i18n_init();


// Next, run the version check.
// If it is successful, continue with initialization for this plugin
if (Getkudos_PhpVersionCheck()) {
	// Only load and run the init function if we know PHP version can parse it
	require_once dirname( __FILE__ ) . '/getkudos_init.php';
	Getkudos_init(__FILE__);
}
